# Documentação: Watchlist e WatchlistChange

## 📋 WATCHLIST

### Funcionalidades

1. **Criação de Watchlist**
   - Criar uma nova watchlist para um usuário
   - Define automaticamente `active = true` e `lastUpdate = LocalDateTime.now()`

2. **Gerenciamento de Filmes**
   - Adicionar filmes à watchlist (via `imdbId`)
   - Remover filmes da watchlist
   - Verificar se filme já está na watchlist antes de adicionar
   - Verificar se filme está na watchlist antes de remover
   - Cria automaticamente o filme no banco se não existir

3. **Listagem e Busca**
   - Listar todas as watchlists com paginação, ordenação e filtros
   - Listar watchlists de um usuário específico
   - Buscar watchlist por ID
   - Listar watchlists arquivadas (inativas) de um usuário
   - Listar watchlists inativas por mais de uma semana

4. **Arquivamento e Ativação**
   - Arquivar watchlist (inativa ao invés de deletar permanentemente)
   - Reativar watchlist arquivada
   - Inativar watchlist
   - Atualiza automaticamente `lastUpdate` ao arquivar/ativar

5. **Histórico de Mudanças**
   - Consultar histórico completo de mudanças de uma watchlist
   - Histórico ordenado por data de criação (mais recente primeiro)
   - Mostra todas as ações (ADD/REMOVE) realizadas na watchlist

6. **Sistema de Rastreamento**
   - Mantém histórico completo de todas as operações (via WatchlistChange)
   - Atualiza `lastUpdate` automaticamente em todas as operações
   - Determina filmes atuais na watchlist baseado na última ação (ADD/REMOVE)

### Endpoints

#### Base URL: `/watchlists`

| Método | Endpoint | Descrição | Parâmetros | Status de Sucesso |
|--------|----------|-----------|------------|-------------------|
| `POST` | `/watchlists` | Criar nova watchlist | Body: `WatchlistCreateDTO` | 201 Created |
| `POST` | `/watchlists/add-movie` | Adicionar filme à watchlist | Body: `AddMovieToWatchlistDTO` | 200 OK |
| `DELETE` | `/watchlists/{watchlistId}/movies/{movieId}` | Remover filme da watchlist | Path: `watchlistId`, `movieId`<br>Query: `userId` | 200 OK |
| `GET` | `/watchlists` | Listar todas (com paginação e filtros) | Query: `page`, `size`, `sort`, `userId`, `name`, `active` | 200 OK |
| `GET` | `/watchlists/user/{userId}` | Listar watchlists de um usuário | Path: `userId` | 200 OK |
| `GET` | `/watchlists/{watchlistId}` | Buscar watchlist por ID | Path: `watchlistId` | 200 OK |
| `DELETE` | `/watchlists/{watchlistId}` | Arquivar watchlist | Path: `watchlistId`<br>Query: `userId` | 200 OK |
| `GET` | `/watchlists/arquivadas/user/{userId}` | Listar watchlists arquivadas | Path: `userId` | 200 OK |
| `GET` | `/watchlists/inativos` | Listar watchlists inativas por mais de uma semana | - | 200 OK |
| `PUT` | `/watchlists/{watchlistId}/inativar` | Inativar watchlist | Path: `watchlistId`<br>Query: `userId` | 200 OK |
| `PUT` | `/watchlists/{watchlistId}/ativar` | Reativar watchlist arquivada | Path: `watchlistId`<br>Query: `userId` | 200 OK |
| `GET` | `/watchlists/{watchlistId}/historico` | Consultar histórico de mudanças | Path: `watchlistId` | 200 OK |

#### Parâmetros de Paginação e Filtros

**Paginação:**
- `page` - Número da página (começa em 0, padrão: 0)
- `size` - Tamanho da página (padrão: 10)
- `sort` - Campo para ordenação (pode repetir para múltiplos campos)
  - Exemplo: `?sort=id,desc&sort=name,asc`

**Filtros para `/watchlists`:**
- `userId` - ID do usuário (busca exata)
- `name` - Busca parcial por nome da watchlist (case-insensitive)
- `active` - Status ativo/inativo (true/false)

**Exemplos:**
```
GET /watchlists?userId=1&active=true
GET /watchlists?page=0&size=10&sort=id,desc&name=assistir&active=true
```

### Erros

#### Erros de Validação (400 Bad Request)

1. **Erro de Validação Bean Validation**
   - **Quando ocorre:** Dados inválidos no body da requisição
   - **Mensagem:** Detalhes dos campos com erro
   - **Exemplo:** Campos obrigatórios ausentes, formato inválido

2. **Usuário não encontrado**
   - **Quando ocorre:** Ao criar watchlist com `userId` inexistente
   - **Mensagem:** `"Usuário não encontrado"`
   - **Status:** 404 Not Found (tratado como RuntimeException)

3. **Sem permissão para modificar**
   - **Quando ocorre:** Usuário tenta modificar watchlist de outro usuário
   - **Mensagem:** `"Você não tem permissão para modificar esta watchlist"`
   - **Status:** 400 Bad Request
   - **Ocorre em:**
     - Adicionar filme
     - Remover filme
     - Arquivar watchlist
     - Inativar watchlist
     - Ativar watchlist

4. **Filme já está na watchlist**
   - **Quando ocorre:** Tentativa de adicionar filme que já está na watchlist
   - **Mensagem:** `"Este filme já está na watchlist"`
   - **Status:** 400 Bad Request

5. **Filme não está na watchlist**
   - **Quando ocorre:** Tentativa de remover filme que não está na watchlist
   - **Mensagem:** `"Este filme não está na watchlist"`
   - **Status:** 400 Bad Request

6. **Filme não encontrado**
   - **Quando ocorre:** Ao remover filme com `movieId` inexistente
   - **Mensagem:** `"Filme não encontrado"`
   - **Status:** 404 Not Found

#### Erros de Recurso Não Encontrado (404 Not Found)

1. **Watchlist não encontrada**
   - **Quando ocorre:** `watchlistId` não existe no banco
   - **Mensagem:** `"Watchlist não encontrada"`
   - **Status:** 404 Not Found
   - **Ocorre em:**
     - Buscar watchlist por ID
     - Adicionar filme
     - Remover filme
     - Arquivar watchlist
     - Inativar watchlist
     - Ativar watchlist
     - Consultar histórico

#### Erros Genéricos (500 Internal Server Error)

1. **Erro interno do servidor**
   - **Quando ocorre:** Erros não previstos
   - **Mensagem:** Mensagem do erro ou "Ocorreu um erro inesperado"
   - **Status:** 500 Internal Server Error

#### Formato de Resposta de Erro

```json
{
  "status": 400,
  "error": "Erro na requisição",
  "message": "Você não tem permissão para modificar esta watchlist",
  "timestamp": "2024-01-15T10:30:00"
}
```

---

## 📋 WATCHLISTCHANGE

### Funcionalidades

1. **Rastreamento de Mudanças**
   - Registra todas as ações realizadas nas watchlists
   - Ações suportadas: `ADD` (adicionar filme) e `REMOVE` (remover filme)
   - Armazena timestamp automático (`createdAt`)

2. **Histórico Completo**
   - Mantém histórico completo de todas as operações
   - Permite consultar histórico ordenado por data
   - Permite buscar mudanças por watchlist
   - Permite buscar mudanças por ação específica

3. **Integração com Watchlist**
   - Cada mudança está vinculada a uma watchlist e um filme
   - Usado para determinar estado atual da watchlist
   - Última ação (ADD/REMOVE) determina se filme está na watchlist

4. **Consultas Especializadas**
   - Buscar todas as mudanças de uma watchlist
   - Buscar mudanças ordenadas por data (mais recente primeiro)
   - Buscar mudanças por watchlist e filme específico
   - Buscar mudanças por tipo de ação (ADD ou REMOVE)

### Endpoints

**Nota:** WatchlistChange não possui endpoints diretos. É acessado através dos endpoints de Watchlist:

| Método | Endpoint | Descrição | Retorna |
|--------|----------|-----------|---------|
| `GET` | `/watchlists/{watchlistId}/historico` | Consultar histórico de mudanças | Lista de `WatchlistHistoryDTO` |

#### Estrutura do Histórico Retornado

```json
[
  {
    "id": 1,
    "action": "ADD",
    "createdAt": "2024-01-15T10:30:00",
    "movie": {
      "id": 1,
      "imdbId": "tt0133093",
      "titulo": "The Matrix",
      "year": "1999",
      "poster": "https://..."
    },
    "watchlistName": "Filmes para Assistir"
  }
]
```

### Métodos do Repository

O `WatchlistChangeRepository` fornece os seguintes métodos:

1. `findByWatchlistId(Long watchlistId)`
   - Retorna todas as mudanças de uma watchlist
   - Ordem: não especificada (usar ordenação manual se necessário)

2. `findByWatchlistIdOrderByCreatedAtDesc(Long watchlistId)`
   - Retorna todas as mudanças de uma watchlist
   - Ordenado por data de criação (mais recente primeiro)

3. `findByWatchlistAndMovie(Watchlist watchlist, Movie movie)`
   - Retorna a mudança específica de um filme em uma watchlist
   - Útil para verificar estado atual

4. `findByWatchlistAndAction(Watchlist watchlist, String action)`
   - Retorna todas as mudanças de um tipo específico (ADD ou REMOVE)
   - Filtra por watchlist e ação

### Erros

WatchlistChange não possui erros específicos, pois é uma entidade gerenciada internamente. Os erros relacionados aparecem através dos endpoints de Watchlist:

1. **Watchlist não encontrada** (ao consultar histórico)
   - **Quando ocorre:** `watchlistId` não existe
   - **Mensagem:** `"Watchlist não encontrada"`
   - **Status:** 404 Not Found
   - **Endpoint:** `GET /watchlists/{watchlistId}/historico`

### Estrutura da Entidade

```java
@Entity
@Table(name = "watchlist_changes")
public class WatchlistChange {
    private Long id;
    private String action; // "ADD" ou "REMOVE"
    private Watchlist watchlist;
    private Movie movie;
    private LocalDateTime createdAt;
}
```

### Lógica de Estado da Watchlist

O sistema determina quais filmes estão atualmente na watchlist analisando o histórico:

1. Agrupa todas as mudanças por filme
2. Ordena por ID (mais recente primeiro)
3. Verifica a última ação:
   - Se última ação = `ADD` → Filme está na watchlist
   - Se última ação = `REMOVE` → Filme não está na watchlist
   - Se não há mudanças → Filme não está na watchlist

Isso permite:
- Histórico completo de todas as operações
- Rastreamento de quando filmes foram adicionados/removidos
- Possibilidade de "desfazer" operações (adicionar novamente após remover)

---

## 🔄 Fluxo de Operações

### Adicionar Filme
1. Valida watchlist existe
2. Valida permissão do usuário
3. Busca ou cria filme no banco
4. Verifica se filme já está na watchlist (última ação = ADD)
5. Cria `WatchlistChange` com ação `ADD`
6. Atualiza `lastUpdate` da watchlist
7. Retorna watchlist atualizada

### Remover Filme
1. Valida watchlist existe
2. Valida permissão do usuário
3. Valida filme existe
4. Verifica se filme está na watchlist (última ação = ADD)
5. Cria `WatchlistChange` com ação `REMOVE`
6. Atualiza `lastUpdate` da watchlist
7. Retorna watchlist atualizada

### Consultar Histórico
1. Valida watchlist existe
2. Busca todas as mudanças ordenadas por data (mais recente primeiro)
3. Mapeia para DTO com informações do filme e watchlist
4. Retorna lista de histórico

---

## 📊 Resumo de Status HTTP

| Status | Quando Ocorre |
|--------|---------------|
| 200 OK | Operações bem-sucedidas (GET, PUT, DELETE) |
| 201 Created | Watchlist criada com sucesso |
| 400 Bad Request | Erros de validação, permissão, ou lógica de negócio |
| 404 Not Found | Recurso não encontrado (watchlist, filme, usuário) |
| 500 Internal Server Error | Erros não previstos |

