package com.example.ApiLetter.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class WebConfig {
    // Configuração para serialização de páginas
    // A serialização é tratada manualmente no controller para manter compatibilidade
}

